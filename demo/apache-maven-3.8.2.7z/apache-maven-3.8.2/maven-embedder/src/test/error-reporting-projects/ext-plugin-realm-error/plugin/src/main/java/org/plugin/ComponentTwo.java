package org.plugin;

public class ComponentTwo
{

    private ComponentOne one;

}
